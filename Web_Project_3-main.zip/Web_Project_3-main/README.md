# Web_Project_3
This repository holds the code for CS 332's (web programming) third project, which is creating the server backend for the social media platform SlugFest.
